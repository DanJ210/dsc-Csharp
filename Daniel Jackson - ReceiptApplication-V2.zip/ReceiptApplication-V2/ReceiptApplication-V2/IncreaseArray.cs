﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReceiptApplication_V2 {
    class IncreaseArray {
        public static void array(ref decimal[] values, int increase) {
            decimal[] array = new decimal[increase];

        }
    }
}
