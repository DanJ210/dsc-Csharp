﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReceiptApplication_V2 {
    class Item {
        public int count { get; set; }
        public decimal price { get; set; }
    }
}
