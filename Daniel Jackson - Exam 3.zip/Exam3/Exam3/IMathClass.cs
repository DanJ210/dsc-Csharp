﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam3 {
    class IMathClass {
        public virtual string Math() {
            return "";
        }
    }
}
